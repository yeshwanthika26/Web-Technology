async function signup() {
  const data = {
    username: signupUsername.value,
    email: signupEmail.value,
    password: signupPassword.value
  };

  const res = await fetch("/signup", {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body:JSON.stringify(data)
  });

  const result = await res.json();
  alert(result.message);
}

async function login() {
  const data = {
    email: loginEmail.value,
    password: loginPassword.value
  };

  const res = await fetch("/login", {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body:JSON.stringify(data)
  });

  const result = await res.json();

  if(result.success){
    alert("Login successful!");
  } else {
    alert(result.message);
  }
}

async function addRecipe() {
  const data = {
    title:title.value,
    category:category.value,
    ingredients:ingredients.value,
    steps:steps.value,
    cookingTime:cookingTime.value,
    servings:servings.value,
    nutrition:nutrition.value,
    video:video.value,
    image:image.value,
    email:email.value
  };

  const res = await fetch("/recipes", {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body:JSON.stringify(data)
  });

  const result = await res.json();
  alert(result.message);

  loadRecipes();
}

async function loadRecipes() {
  const res = await fetch("/recipes");
  const recipes = await res.json();

  const recipeDiv = document.getElementById("recipes");
  recipeDiv.innerHTML = "";

  recipes.forEach(recipe => {
    recipeDiv.innerHTML += `
      <div class="card">
        <img src="${recipe.image}" alt="Recipe">
        <h3>${recipe.title}</h3>
        <p><b>Category:</b> ${recipe.category}</p>
        <p><b>Ingredients:</b> ${recipe.ingredients}</p>
        <p><b>Steps:</b> ${recipe.steps}</p>
        <p><b>Cooking Time:</b> ${recipe.cookingTime}</p>
        <p><b>Servings:</b> ${recipe.servings}</p>
        <p><b>Nutrition:</b> ${recipe.nutrition}</p>
        <a href="${recipe.video}" target="_blank">Watch Video</a>
        <br><br>
        <button onclick="likeRecipe(${recipe.id})">❤️ ${recipe.likes}</button>
        <button onclick="deleteRecipe(${recipe.id})">Delete</button>
      </div>
    `;
  });
}

async function likeRecipe(id){
  await fetch(`/recipes/${id}/like`, {
    method:"PUT"
  });

  loadRecipes();
}

async function deleteRecipe(id){
  await fetch(`/recipes/${id}`, {
    method:"DELETE"
  });

  loadRecipes();
}

document.getElementById("search").addEventListener("input", async function() {
  const keyword = this.value.toLowerCase();

  const res = await fetch("/recipes");
  const recipes = await res.json();

  const filtered = recipes.filter(r =>
    r.title.toLowerCase().includes(keyword) ||
    r.category.toLowerCase().includes(keyword)
  );

  const recipeDiv = document.getElementById("recipes");
  recipeDiv.innerHTML = "";

  filtered.forEach(recipe => {
    recipeDiv.innerHTML += `
      <div class="card">
        <img src="${recipe.image}" alt="Recipe">
        <h3>${recipe.title}</h3>
        <p>${recipe.category}</p>
      </div>
    `;
  });
});

loadRecipes();
