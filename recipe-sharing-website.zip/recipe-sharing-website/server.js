const express = require("express");
const bodyParser = require("body-parser");
const sqlite3 = require("sqlite3").verbose();
const cors = require("cors");
const nodemailer = require("nodemailer");
const path = require("path");

const app = express();
const db = new sqlite3.Database("./recipes.db");

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    email TEXT,
    password TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    category TEXT,
    ingredients TEXT,
    steps TEXT,
    cookingTime TEXT,
    servings TEXT,
    nutrition TEXT,
    video TEXT,
    image TEXT,
    likes INTEGER DEFAULT 0
  )`);
});

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "YOUR_EMAIL@gmail.com",
    pass: "YOUR_APP_PASSWORD"
  }
});

app.post("/signup", (req, res) => {
  const { username, email, password } = req.body;

  db.run(
    "INSERT INTO users(username,email,password) VALUES(?,?,?)",
    [username, email, password],
    function(err) {
      if (err) return res.status(500).send(err);

      res.send({ message: "Signup successful!" });
    }
  );
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;

  db.get(
    "SELECT * FROM users WHERE email=? AND password=?",
    [email, password],
    (err, row) => {
      if (row) {
        res.send({ success: true, user: row });
      } else {
        res.send({ success: false, message: "Invalid login" });
      }
    }
  );
});

app.get("/recipes", (req, res) => {
  db.all("SELECT * FROM recipes", [], (err, rows) => {
    res.send(rows);
  });
});

app.post("/recipes", (req, res) => {
  const {
    title,
    category,
    ingredients,
    steps,
    cookingTime,
    servings,
    nutrition,
    video,
    image,
    email
  } = req.body;

  db.run(
    `INSERT INTO recipes 
    (title,category,ingredients,steps,cookingTime,servings,nutrition,video,image)
    VALUES (?,?,?,?,?,?,?,?,?)`,
    [
      title,
      category,
      ingredients,
      steps,
      cookingTime,
      servings,
      nutrition,
      video,
      image
    ],
    function(err) {
      if (err) return res.status(500).send(err);

      const mailOptions = {
        from: "YOUR_EMAIL@gmail.com",
        to: email,
        subject: "Recipe Uploaded Successfully",
        text: `Your recipe "${title}" has been added successfully!`
      };

      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.log(error);
        } else {
          console.log("Email sent: " + info.response);
        }
      });

      res.send({ message: "Recipe added successfully!" });
    }
  );
});

app.put("/recipes/:id/like", (req, res) => {
  db.run(
    "UPDATE recipes SET likes = likes + 1 WHERE id=?",
    [req.params.id],
    function(err) {
      res.send({ message: "Liked!" });
    }
  );
});

app.delete("/recipes/:id", (req, res) => {
  db.run("DELETE FROM recipes WHERE id=?", [req.params.id], function(err) {
    res.send({ message: "Recipe deleted!" });
  });
});

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
