STEP 1:
Install Node.js

STEP 2:
Open this folder in VS Code

STEP 3:
Open Terminal and run:

npm install

STEP 4:
Start the server:

npm start

STEP 5:
Open browser:
http://localhost:3000

EMAIL SETUP:
Open server.js
Replace:

YOUR_EMAIL@gmail.com
YOUR_APP_PASSWORD

with your Gmail and App Password.
